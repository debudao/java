
public class Chapter2_3 {

	public static void main(String[] args) {
		int x = 100;
		int y = 200;
		System.out.println("x+y="+x+y);
		System.out.println(x+y+"=x+y");
		System.out.println(+x+y);
		System.out.println(x+y+"=x+y"+x+y);

	}

}
